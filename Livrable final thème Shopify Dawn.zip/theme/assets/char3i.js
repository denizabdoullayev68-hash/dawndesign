/* Char3i Barber — comportements storefront. Idempotent : le fichier peut être chargé plusieurs fois. */
(function () {
  'use strict';
  if (window.__char3iLoaded) return;
  window.__char3iLoaded = true;

  var money = function (cents, format) {
    var v = (cents / 100).toFixed(2).replace('.', ',');
    return (format || '{{amount}} €').replace(/\{\{\s*[a-z_]+\s*\}\}/i, v);
  };

  /* ---- Sélecteur de senteur sur les cartes et la fiche produit ---- */
  if (!customElements.get('c3-variant-pills')) {
    customElements.define(
      'c3-variant-pills',
      class extends HTMLElement {
        connectedCallback() {
          var raw = this.querySelector('[data-c3-variants]');
          this.variants = raw ? JSON.parse(raw.textContent) : [];
          this.format = this.dataset.moneyFormat || '{{amount}} €';
          this.input = this.querySelector('[data-c3-id]');
          var scope = this.closest('[data-c3-scope]');
          this.priceEl = scope ? scope.querySelector('[data-c3-price]') : null;
          this.imgEl = scope ? scope.querySelector('[data-c3-image]') : null;
          this.btn = scope ? scope.querySelector('[data-c3-submit]') : null;
          this.noteEl = scope ? scope.querySelector('[data-c3-note]') : null;
          this.addEventListener('click', this.onClick.bind(this));
        }
        onClick(e) {
          var btn = e.target.closest('[data-c3-variant]');
          if (!btn || btn.disabled) return;
          var id = btn.getAttribute('data-c3-variant');
          this.querySelectorAll('[data-c3-variant]').forEach(function (b) {
            b.setAttribute('aria-pressed', b === btn ? 'true' : 'false');
          });
          if (this.input) this.input.value = id;
          var v = this.variants.find(function (x) {
            return String(x.id) === String(id);
          });
          if (!v) return;
          if (this.priceEl) this.priceEl.textContent = money(v.price, this.format);
          if (this.imgEl && v.image) this.imgEl.src = v.image;
          if (this.noteEl) this.noteEl.textContent = v.title;
          if (this.btn) {
            this.btn.disabled = !v.available;
            var label = this.btn.querySelector('[data-c3-label]');
            if (label) label.textContent = v.available ? this.btn.dataset.labelAdd : this.btn.dataset.labelOut;
          }
          if (this.dataset.updateUrl === 'true') {
            var url = new URL(window.location.href);
            url.searchParams.set('variant', id);
            window.history.replaceState({}, '', url.toString());
          }
        }
      }
    );
  }

  /* ---- Quiz adaptatif : le parcours dépend du besoin déclaré ---- */
  if (!customElements.get('c3-quiz')) {
    customElements.define(
      'c3-quiz',
      class extends HTMLElement {
        connectedCallback() {
          var node = this.querySelector('[data-c3-quiz-data]');
          if (!node) return;
          try {
            this.data = JSON.parse(node.textContent);
          } catch (err) {
            return;
          }
          this.stage = this.querySelector('[data-c3-stage]');
          this.answers = {};
          this.history = [];
          this.total = Number(this.dataset.steps || 3);
          this.render(this.data.start);
        }
        progress(i) {
          var bar = this.querySelector('[data-c3-bar]');
          if (!bar) return;
          bar.innerHTML = '';
          for (var n = 0; n < this.total; n++) {
            var s = document.createElement('span');
            if (n < i) s.setAttribute('data-on', '');
            bar.appendChild(s);
          }
        }
        render(key) {
          var step = this.data.steps[key];
          if (!step) return this.result();
          this.current = key;
          this.progress(this.history.length);
          var opts = step.opts
            .map(function (o, i) {
              return (
                '<button type="button" class="c3-opt" data-c3-opt="' +
                i +
                '"><span class="c3-opt__k">' +
                String.fromCharCode(65 + i) +
                '</span><span>' +
                o.label +
                '</span></button>'
              );
            })
            .join('');
          this.stage.innerHTML =
            '<p class="c3-quiz__q">' +
            step.q +
            '</p>' +
            (step.hint ? '<p class="c3-quiz__hint">' + step.hint + '</p>' : '') +
            '<div class="c3-quiz__opts' +
            (step.opts.length > 3 ? ' c3-quiz__opts--2' : '') +
            '">' +
            opts +
            '</div>' +
            (this.history.length
              ? '<div class="c3-quiz__foot"><button type="button" class="c3-quiz__back" data-c3-back>Revenir</button></div>'
              : '');
          var self = this;
          this.stage.querySelectorAll('[data-c3-opt]').forEach(function (b) {
            b.addEventListener('click', function () {
              var o = step.opts[Number(b.getAttribute('data-c3-opt'))];
              Object.assign(self.answers, o.set || {});
              self.history.push(key);
              if (o.next && self.data.steps[o.next]) self.render(o.next);
              else self.result();
            });
          });
          var back = this.stage.querySelector('[data-c3-back]');
          if (back)
            back.addEventListener('click', function () {
              var prev = self.history.pop();
              self.render(prev);
            });
        }
        match() {
          var a = this.answers;
          var hit = (this.data.rules || []).find(function (r) {
            return Object.keys(r.if).every(function (k) {
              return a[k] === r.if[k];
            });
          });
          return this.data.outcomes[hit ? hit.outcome : this.data.fallback];
        }
        result() {
          var o = this.match();
          this.progress(this.total);
          if (o && o.variantFrom && this.answers[o.variantFrom]) {
            o = Object.assign({}, o, {
              url: o.url + (o.url.indexOf('?') === -1 ? '?' : '&') + 'variant=' + this.answers[o.variantFrom],
            });
          }
          if (!o) {
            this.stage.innerHTML = '<p class="c3-quiz__q">Réponse indisponible pour le moment.</p>';
            return;
          }
          this.stage.innerHTML =
            '<div class="c3-quiz__result">' +
            '<div class="c3-quiz__rmedia">' +
            (o.img ? '<img src="' + o.img + '" alt="' + o.title + '" loading="lazy" width="600" height="600">' : '') +
            '</div>' +
            '<div style="display:flex;flex-direction:column;gap:14px;align-items:flex-start">' +
            '<p class="c3-eyebrow" style="color:var(--c3-gold)">' +
            (o.badge || 'Ta réponse') +
            '</p>' +
            '<p class="c3-quiz__q">' +
            o.title +
            '</p>' +
            '<p class="c3-lead">' +
            o.why +
            '</p>' +
            (o.price ? '<p style="font-size:19px;font-weight:650">' + o.price + '</p>' : '') +
            '<a class="c3-btn" href="' +
            o.url +
            '">' +
            (o.cta || 'Voir le produit') +
            '</a>' +
            '<button type="button" class="c3-quiz__back" data-c3-restart>Recommencer</button>' +
            '</div></div>';
          var self = this;
          var again = this.stage.querySelector('[data-c3-restart]');
          if (again)
            again.addEventListener('click', function () {
              self.answers = {};
              self.history = [];
              self.render(self.data.start);
            });
          this.dispatchEvent(new CustomEvent('c3:quiz-complete', { bubbles: true, detail: this.answers }));
        }
      }
    );
  }
})();
